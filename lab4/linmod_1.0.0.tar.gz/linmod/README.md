
<!-- README.md is generated from README.Rmd. Please edit that file -->

# linmod

<!-- badges: start -->
[![R](https://github.com/Johhed15/Lab4_R/actions/workflows/r.yml/badge.svg)](https://github.com/Johhed15/Lab4_R/actions/workflows/r.yml)
<!-- badges: end -->

The goal of linmod is to …
